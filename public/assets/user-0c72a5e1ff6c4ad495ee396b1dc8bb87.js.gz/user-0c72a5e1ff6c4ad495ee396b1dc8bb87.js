
$(document).ready(function(){

	alert("hello there");
});
